import os
from langchain.chat_models import ChatOpenAI
from langchain.schema import HumanMessage

def analisar_fundador(dados):
    openai_key = os.getenv("OPENAI_API_KEY")
    if not openai_key:
        return "⚠️ API da OpenAI não configurada"

    llm = ChatOpenAI(openai_api_key=openai_key, temperature=0.5)

    prompt = f"""
    Analise o seguinte fundador:
    Nome: {dados['nome']}
    Idade: {dados['idade']}
    Experiência (anos): {dados['experiencia']}
    Formação: {dados['formacao']}
    Visão: {dados['visao']}

    Retorne um parágrafo resumido sobre o potencial dele como empreendedor.
    """
    resposta = llm([HumanMessage(content=prompt)])
    return resposta.content
