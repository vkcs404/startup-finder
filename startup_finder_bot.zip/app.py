from flask import Flask, render_template, request
import json
from langchain_module.analyzer import analisar_fundador
from utils.heuristics import pontuar_fundador
import random
from faker import Faker

app = Flask(__name__)
fake = Faker()

# Gera dados aleatórios de fundadores
def gerar_fundadores(n=5):
    fundadores = []
    for _ in range(n):
        fundador = {
            "nome": fake.name(),
            "idade": random.randint(20, 60),
            "experiencia": random.randint(0, 15),
            "formacao": random.choice(["Tecnologia", "Negócios", "Design", "Outro"]),
            "visao": fake.text(max_nb_chars=150)
        }
        fundadores.append(fundador)
    return fundadores

@app.route("/")
def index():
    fundadores = gerar_fundadores()
    resultados = []
    for f in fundadores:
        analise = analisar_fundador(f)
        score = pontuar_fundador(f)
        resultados.append({"fundador": f, "analise": analise, "pontuacao": score})
    return render_template("index.html", resultados=resultados)

if __name__ == '__main__':
    app.run(debug=True)
