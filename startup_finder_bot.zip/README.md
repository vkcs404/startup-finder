# 🚀 Startup Finder Bot

Este projeto em Flask usa o LangChain com OpenAI para analisar dados simulados de fundadores de startups e gerar perfis com pontuação baseada em heurísticas.

## 🧠 Tecnologias

- Flask
- LangChain + OpenAI
- Faker (geração de dados aleatórios)
- Heurísticas simples para pontuação

## ▶️ Como rodar

1. Clone este repositório:
```bash
git clone https://github.com/seuusuario/startup-finder-bot.git
cd startup-finder-bot
```

2. Instale os pacotes:
```bash
pip install -r requirements.txt
```

3. Configure sua API da OpenAI:
```bash
export OPENAI_API_KEY=sua-chave-aqui
# no Windows: set OPENAI_API_KEY=sua-chave-aqui
```

4. Rode o projeto:
```bash
python app.py
```

5. Acesse `http://localhost:5000`

## ✨ Exemplo de Resultado

Cada fundador gerado recebe:
- Análise da IA sobre seu potencial
- Pontuação de 0 a 100 com base em experiência, formação e visão

## 📄 Licença

MIT
