def pontuar_fundador(f):
    score = 0
    if f['experiencia'] >= 10:
        score += 40
    elif f['experiencia'] >= 5:
        score += 25
    else:
        score += 10

    if f['formacao'] in ['Tecnologia', 'Negócios']:
        score += 30
    else:
        score += 15

    if len(f['visao']) > 100:
        score += 30
    else:
        score += 10

    return min(score, 100)
